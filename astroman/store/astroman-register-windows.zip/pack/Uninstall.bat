@echo off
chcp 65001 >nul
title Astroman register - remove shortcuts
powershell -NoProfile -ExecutionPolicy Bypass -Command "$n='Astroman Salaro.lnk'; foreach($d in @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'), [Environment]::GetFolderPath('Startup'))){ $p=Join-Path $d $n; if(Test-Path $p){Remove-Item $p -Force; Write-Host ('Removed ' + $p)} }; Write-Host 'Done. The saved device link stays in %LOCALAPPDATA%\AstromanRegister (delete that folder to forget it).'"
pause
