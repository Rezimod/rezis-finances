﻿# Astroman register (სალარო) — Windows installer
# Creates an app window (Edge or Chrome), shortcuts on the Desktop and Start menu, optional autostart and kiosk mode.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Base = 'https://rezimod.github.io/rezis-finances/astroman/store/'
$Name = 'Astroman Salaro'
$Home2 = Join-Path $env:LOCALAPPDATA 'AstromanRegister'
New-Item -ItemType Directory -Force -Path $Home2 | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'astroman.ico') (Join-Path $Home2 'astroman.ico') -Force
$Ico = Join-Path $Home2 'astroman.ico'

Write-Host ''
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host '   ASTROMAN REGISTER  /  ასტრომანი სალარო' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ''

# 1. browser
$edge = @("$env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge -and -not $chrome) { Write-Host 'Neither Microsoft Edge nor Google Chrome was found. Install one of them and run Install.bat again.' -ForegroundColor Red; Read-Host 'Press Enter to close'; exit 1 }
$browser = $chrome; $kind = 'Chrome'
if ($edge -and -not $chrome) { $browser = $edge; $kind = 'Edge' }
if ($edge -and $chrome) {
  $pick = Read-Host 'Both Chrome and Edge are installed. Use Chrome (C) or Edge (E)? [C]'
  if ($pick -match '^[eE]') { $browser = $edge; $kind = 'Edge' }
}
Write-Host "Using $kind : $browser"

# 2. device link
$linkFile = Join-Path $Home2 'link.txt'
$saved = if (Test-Path $linkFile) { (Get-Content $linkFile -Raw).Trim() } else { '' }
Write-Host ''
Write-Host 'Paste the DEVICE LINK from the finance desk (Store sales -> Register setup -> Copy device link).'
Write-Host 'It looks like  https://rezimod.github.io/rezis-finances/astroman/store/#connect=...'
if ($saved) { Write-Host "Press Enter to keep the saved link." }
else { Write-Host 'Press Enter to skip for now (you can paste it inside the app later).' }
$link = (Read-Host 'Device link').Trim()
if (-not $link -and $saved) { $link = $saved }
if ($link -and $link -notmatch '#connect=') { Write-Host 'That is not a device link (no #connect= part). Skipping it.' -ForegroundColor Yellow; $link = '' }
if ($link) { Set-Content -Path $linkFile -Value $link -Encoding UTF8 }
$url = if ($link) { $link } else { $Base }

# 3. options
$auto = (Read-Host 'Start the register automatically when Windows starts? (Y/N) [Y]')
$auto = ($auto -eq '' -or $auto -match '^[yY]')
$kiosk = (Read-Host 'Kiosk mode: full screen, no way out except Alt+F4? (Y/N) [N]')
$kiosk = ($kiosk -match '^[yY]')

# 4. shortcuts
if ($kind -eq 'Chrome') {
  $args = "--app=`"$url`" --start-maximized"
  if ($kiosk) { $args = "--kiosk --kiosk-printing --app=`"$url`"" }
} else {
  $args = "--app=`"$url`" --start-maximized"
  if ($kiosk) { $args = "--kiosk `"$url`" --edge-kiosk-type=fullscreen --no-first-run" }
}
$shell = New-Object -ComObject WScript.Shell
function Make-Shortcut($path) {
  $sc = $shell.CreateShortcut($path)
  $sc.TargetPath = $browser
  $sc.Arguments = $args
  $sc.IconLocation = "$Ico,0"
  $sc.Description = 'Astroman register / ასტრომანი სალარო'
  $sc.WorkingDirectory = Split-Path $browser
  $sc.Save()
}
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'
$startup = [Environment]::GetFolderPath('Startup')
Make-Shortcut (Join-Path $desktop "$Name.lnk")
Make-Shortcut (Join-Path $startMenu "$Name.lnk")
$startupLnk = Join-Path $startup "$Name.lnk"
if ($auto) { Make-Shortcut $startupLnk } elseif (Test-Path $startupLnk) { Remove-Item $startupLnk -Force }
Write-Host ''
Write-Host "Shortcuts created: Desktop, Start menu$(if ($auto) { ', Startup' })." -ForegroundColor Green

# 5. first start
Write-Host 'Opening the register now...'
Start-Process -FilePath $browser -ArgumentList $args
Write-Host ''
Write-Host 'NEXT:' -ForegroundColor Cyan
Write-Host ' - Wait for the green dot "შენახულია" at the top right of the register window.'
if (-not $link) { Write-Host ' - The app asks for the device link: paste it there (Store sales -> Register setup on the finance desk).' }
Write-Host ' - Right-click the register icon on the taskbar -> "Pin to taskbar".'
Write-Host ' - Barcode scanner: just plug it in. Receipt printer: set it as the default printer, choose 80 mm paper on the first print.'
Write-Host ''
Read-Host 'Press Enter to close this window'
