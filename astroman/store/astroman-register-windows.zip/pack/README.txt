﻿ASTROMAN REGISTER (სალარო) — WINDOWS INSTALL
=============================================

What this is
------------
The register is a web app that runs in its own window through Microsoft Edge or Google Chrome,
like Optimo's app. It works offline, keeps product pictures on the PC, and sends every sale
to the owner's finance desk within a minute. Nothing else needs to be installed.

Before you start (owner, once)
------------------------------
1. Apps Script: paste the new Code.gs and deploy a NEW VERSION (Deploy -> Manage deployments -> pencil -> Version: New -> Deploy).
2. Finance desk -> Store sales -> Register setup: paste the register key (POS_KEY), Save key, Check the backend.
3. Same page: add the consultants with 4-digit PINs, Save. Fill in the receipt header, Save.
4. Same page: "Copy device link". Keep it private - it contains the register key.

Install on the shop PC (5 minutes)
----------------------------------
1. Unzip this folder anywhere (e.g. Desktop).
2. Double-click  Install.bat
   - If Windows shows "Windows protected your PC": click "More info" -> "Run anyway".
3. Answer the questions:
   - Chrome or Edge (if both are installed).
   - Paste the device link (right-click to paste), Enter. You can skip it and paste it inside the app later.
   - Autostart with Windows: Y.
4. The register opens. Wait for the green dot "შენახულია" top right. Log in with a consultant name + PIN.
5. Right-click the register icon on the taskbar -> Pin to taskbar. F11 switches full screen on and off.

Shortcuts are created on the Desktop and in the Start menu ("Astroman Salaro").
Uninstall.bat removes the shortcuts.

Barcode scanner
---------------
Any USB scanner in keyboard mode (factory default). Plug in, no driver. On the sale screen
scan the barcode on the product - it is added to the order. The barcode must match the code
shown under the product in the register (the Optimo barcode).

Receipt printer (80 mm thermal)
-------------------------------
1. Install the printer's driver, set it as the Windows default printer.
2. In the register keep "ქვითრის ამობეჭდვა" switched on at payment.
3. The first print shows the Windows print dialog: pick the receipt printer, paper 80 mm,
   margins none, no headers/footers. The browser remembers the choice.
4. For printing without the dialog, add  --kiosk-printing  to the shortcut's Target (right-click the shortcut -> Properties).
Receipts are non-fiscal.

Second register (tablet / phone)
--------------------------------
Finance desk -> Store sales -> Register setup shows a QR code. Scan it with the tablet camera,
then "Add to Home screen". Each device keeps its own shift.

Problems
--------
"ბექენდი ძველია"        -> the Apps Script still runs the old code (step 1 above).
"არასწორი გასაღები"      -> the device link holds an old key; copy a fresh device link.
Products do not load     -> no internet, or press "Update from Optimo list" on the finance desk Products page.
Wrong stock / price      -> the finance desk Products page is the source of truth; edit there.
Move to another PC       -> in the app: menu -> გათიშვა (when everything is saved), then install on the new PC.
