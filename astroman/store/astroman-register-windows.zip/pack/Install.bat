@echo off
chcp 65001 >nul
title Astroman register - install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
